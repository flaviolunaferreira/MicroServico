package the.coyote.organize;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrganizeApplicationTests {

	@Test
	void contextLoads() {
	}

}
