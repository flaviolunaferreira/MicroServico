package the.coyote.permissoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PermissoesApplicationTests {

	@Test
	void contextLoads() {
	}

}
